# ff4 patches

Collection of patch files and previews of their changes, for a rom with CRC32 = 23084FCD.

Also contains premade collections of patches (style packs) for the patched rom, in "/new style packs (change many things)"

Patching webapps supported by these files are available at:
- [FF4 Ultima Plus Patcher](https://ultima-plus-stylepacks.vercel.app/)
- [FF4 Ultima Plus Style Patcher](https://ultima-plus-patchapp.vercel.app/)

Built with critical logic from:
[RomPatcher.js](https://github.com/marcrobledo/RomPatcher.js)

By xJ4cks, FlamePurge, Gedankenschild, Nicoc1991, MObreck and others