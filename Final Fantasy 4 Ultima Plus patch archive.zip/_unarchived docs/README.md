# FF4 Ultima Plus Patches

Collection of patch files and previews of their changes.

All patches work with most known FFII and FFIVJ ROMs, but are created for the FF4 Ultima and FF4 Ultima Plus projects.

Patching webapp supported by these files available at:
- [FF4 Ultima Plus Patcher](https://ultima-plus.vercel.app/)

Built with some logic from:
- [RomPatcher.js](https://github.com/marcrobledo/RomPatcher.js)
- [xJ4cks](https://jacks.media)
- CHatGPT4

Optional patch contents by xJ4cks, FlamePurge, Gedankenschild, Nicoc1991, MObreck, mrBrawndo, red man and others