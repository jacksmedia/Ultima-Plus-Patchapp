FF4 Ultima Alternate Graphics Patches
-------------------------------------
Dozens of new character options are available for map sprites, battle sprites, and menu portrait art.
Please note the original game sourced for many of the sprite imports:
- RK = FF Record Keeper, extinct mobile game
- PR = FFIV Pixel Remaster, 2017
- WS = FFIV on the WonderSwan, Japanese handheld from 20th century
- PSP = FFIV on the Playstation Portable

Special enhanced monster graphics patches exist, too!

Please refer to each addendum's readme and PNG files for previews.

These IPS patches only work with a patched, no-header version of FF4 Ultima (Classic or Plus).


--- Author Credits ---
----------------------

--- [Gedankenschild] Enemy Sprites 4bpp Upgrade
  -- v2 of the 4bpp upgrade brings back several enemies to their original sizes: Ogre, Naga, RockMoth, Centaur, and Weeper types. v1 is also included for those that prefer their smaller sizes instead.

--- [Nicoc1991] Variety of alternate sprites from many sources & some custom work, too (Ultima RK)!

--- [Tsushiy] Alternate Rosa battle sprites, custom Golbez portraits; WonderSwan map sprites; PSP portrait imports

--- [mrBrawndo] Super Remaster Portrait Pack / Amano Portrait Cecil-D / Amano Portrait Cecil-P

--- [MObreck] Pixel Remaster battle and map sprites; All the Bravest monster sprite

--- [T92] Record Keeper battle sprites imports / custom Paladin Cecil battle sprites

--- [xJ4cks] Variety of alternate sprites, many recolors of other sprites

--- [red man] Variety of alternate sprites from many sources, NPC edits
 -- "Scholars be Bountiful" adds Scholar NPCs throughout the game (they are very rare otherwise)

--- [gvdn] Custom Paladin Cecil map sprites based on WonderSwan art, alternate WS portraits

--- [FlamePurge] PR-style Rosa Portrait

--- [El Forko] recolors of classic battle sprites

--- [AerospaceCoot35] Custom map sprite


!! Not all of these patches are compatible together, so take care!!

FFIV MSU-1 patch (not included) is known to cause visual bugs with the 4bpp Monster graphics patches. 

If you have any questions or issues, feel free to reach out to our team on the FF4 Ultima Discord at: https://discord.gg/4MqjwJt

Enjoy!!

---------------------------------------------------------

More info:

http://www.8bitfan.info/
https://discord.gg/4MqjwJt
https://ultima-plus.vercel.app/
http://romhackwiki.8bitfan.info
https://www.romhacking.net/hacks/4134/

---------------------------------------------------------