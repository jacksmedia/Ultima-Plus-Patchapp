   FINAL FANTASY IV - ULTIMA PLUS
         Modern Names v1.1
            epigonone


A. OVERVIEW
   ========
1. Modern Final Fantasy Names (-aga spells, Scarmiglione, etc),
   with some necessary liberties because of extreme space limitations.
2. Can change the name of FFIV Ultima's Secret Character, into his true name, via Namingway.
3. Uses Slim Fonts because otherwise it will be very hard to read the long names.
4. New Icon for Long Range and Ice Element.
5. Shortened other names.



B. NOTES
   =====
1. This patch is NOT COMPATIBLE WITH ANY OPTIONAL FONT PATCHES.
2. This patch was made for smartphones/small screen,
   but playing on PC/big screen should technically have better visibility.
3. Recommended to be played using Emulator Upscaling Filters for further better visibility.
4. Because of limitations, original FFIV Ultima Plus has better overall technical quality.
   If you are not into Modern Names, please play the original FFIV Ultima.



C. CHANGELOG
   =========

   v1.1   - New Names' dialogue consistency second recheck and edited/improved.
          - More letters for BarnabasZ, Fortify, and Apocalypse.
          - New Game Plus won't carry the Secret character's custom name,
            to avoid immersion breaking story.

   v1.0   - First Patch.



D. MOST NAME CHANGES DETAIL
   ========================

Many of the names are also referenced from Flamepurge's 'SquishBGone' Patch.
Please check out their amazing works!

Because of space limitations, many long spell names can't have magic icons anymore.
To compensate that, some spells with hard to guess elements has got a specific elemental Icons after their names.

BASE MAGIC:
Cure       Cura        Curaga      Curaja     Curava
Fire       Fira        Firaga      Firaja
Blizzard   Blizzara    Blizzaga    Blizzaja
Thunder    Thundara    Thundaga    Thundaja
Raise                  Arise

WHITE MAGIC:123456
Ultima   -> (Added 'Non-Elemental' icon)
Safe     -> Protect
Wall     -> Reflect
Mute     -> Silence
Heal     -> Esuna
Scan     -> Libra
Pearl    -> Holy
White    -> Smite
Holy     -> Judge // SHORT FOR "Judgment"
Confs    -> Charm
Charm    -> Entice

BLACK MAGIC: 123456
Meteo     -> Meteor (Added 'Holy icon')
Demi      -> Gravity
Psych     -> Osmose
Virus     -> Bio
Bio       -> Blight
Scrge     -> Razer
Burst     -> Ruin (Added 'Non-Elemental' icon)
Nuke      -> Flare (Added 'Non-Elemental' icon)
Flare     -> Melt(down)
SFlare    -> Solar (Added 'Non-Elemental' icon)
StFall    -> Star (Added 'Non-Elemental' icon)
BlackHol  -> Void
SNova     -> Nova (Added 'Non-Elemental' icon)

ESPER -> EIDOLON:123456
Phnix         -> Phoenix
Levia         -> Leviathan
Baham         -> Bahamut
NeoBh         -> NeoBahamut

EIDOLON ATTACKS: 12345678
Inferno       -> HellFire
Gem Dust      -> Dmd.Dust
BoltFist      -> Jdg.Bolt
AtomEdge      -> Zantetsu
TrueEdge      -> Zanmato
RbirthFlame   -> Rebirth
Reinforce     -> Revivify

SPECIAL MAGIC:123456
Lance      -> Same (Added 'Drain HP' icon)
HiWind     -> Talon (Does not feels right changing it to Aera. Keeps its unique Wind icon)
MtGrd      -> Aegis (Because the Devs said this is a Paladin's exclusive, not a blue magic)
Rflect     -> Veil (Because Wall is now Reflect, and this is also a Paladin Exclusive)
Illusn     -> Elude
FBomb      -> Flash

BOSSES:        12345678
Mist Rage   -> MistRage
LiquidFlame -> LiquFire // SHORT FOR "Liquid Fire"
Crystal D.  -> CrystalD // SHORT FOR "Crystal Dragon"
Cal         -> Calca
Calbrina    -> Calcabrina
Barnab      -> Barnabas
Barnab-Z    -> BarnabasZ
Milon       -> Scarmiglione
Milon Z     -> ScarmiglionZ
Valvalis    -> Barbariccia
Rubicant    -> Rubicante

CLASSES:    1234567
Caller   -> Summoner
All-Mage -> Lunarian
Sorcerer -> Lunarian

COMMANDS:  12345
Ninja   -> Jutsu (To avoid redundancy with class name)

ENEMIES:       12345678
Mage        -> MindFlayer
Float Eye   -> FloatEye
Sword Rat   -> SwordRat
Mini Mage   -> MiniMage
Water Hag   -> WaterHag
Water Bug   -> WaterBug
Electrfish  -> BoltFish
BlackKnight -> Warlord
Ice Knight  -> IceBlade
Tiny Toad   -> TinyToad
Rock Moth   -> RockMoth
Trap Door   -> TrapDoor
Pink Puff   -> PinkPuff
Fatal Eye   -> FatalEye

ENEMY ATTACKS: 12345678
AtomicRay   -> Atom Ray
Rock Beak   -> RockBeak
Mind Blow   -> MindBlow
Foul Odor   -> FoulOdor
SnowStorm   -> IceStorm
PoisonGas   -> VenomGas
Whirlwind   -> Storm
DragnBrth   -> Breath
LightFlash  -> Glimmer
Crystalize  -> Calcify
Tidal Wave  -> TideWave
Flame Gale  -> FireGale
Overclock   -> De-limiter
ShortCirct  -> GlitchOut
AtomicBlast -> A-Blast
AtomicFire  -> AtomFire
DarkBlaze   -> DarkFire

OTHER ATTACKS:
Bursting Ballad -> Ruinous Rhapsody

TOOLS:     12345
AtmRay  -> A.Ray // SHORT FOR "Atom Ray"
Glance  -> Glare
Xhaust  -> Smog
Gossp   -> Sneer
StnGn   -> Taser
Blast   -> Bomb
Powder  -> Blind(Dust)
ElecMg  -> Shock
Blaster -> Blast
Adren   -> Boost
Explod  -> BOOM!
Needle  -> Thorn

LONG ATTACK NAMES:12345678
Powder         -> BlindDust
Needle         -> Needler
Sword Rain     -> Swordfall

HEALING ITEMS: 12345678
Life        -> PhoenixDn
Heal        -> BodyHeal
Abilify     -> MindHeal

SWORDS:         12345678
Deathbringer -> Death // "Deathbringer" IN DIALOGUE
Nightbringer -> Helheim
Piggy Stick  -> Pig Stick
Lightbringer -> Asgard

SPEARS:         12345678
WindSpear    -> Wind (Spear)
HolyLance    -> Holy (Lance)

CLAWS:          12345678
Fire Claw    -> Fire
Ice Claw     -> Ice
Kaiser Claw  -> Kaiser (Claw)
TigerFang    -> Tiger (Fang)

WHIPS:          12345678
FlameLash    -> FireLash
SlayingTail  -> Slaying (Tail)

FLAILS:         12345678
Chain Flail  -> Flail

BOOMERANGS:     12345678
Rising Sun   -> RisenSun
Wing Edge    -> WingEdge

KATANA:         12345678
Tempest      -> Kazekiri
Eclipse      -> Gesshoku

SHURIKEN:       12345678
Ninja Star   -> Ninja (Star)

HELMETS:        12345678
WizardHat    -> Wizard (Hat)
GlassMask    -> Glass (Mask)
GoldHairpin  -> Gold Pin // SHORT FOR "Gold Hairpin"
TigerMask    -> Tiger (Mask)

ARMOR:          12345678
PrismRobe    -> Prism (Robe)
Black Robe   -> Black (Robe)
WhiteRobe    -> White (Robe)
Black Belt   -> Blk.Belt // SHORT FOR "Black Belt"

ARM-WEAR:       12345678
ThiefRing    -> Thief R.(Ring)
BerserkRing  -> Berserk (Ring)
OmegaRing    -> Omega (Ring)
Ruby Ring    -> RubyRing
Silver Ring  -> Silver (Ring)
Rune Ring    -> RuneRing

ATTACK ITEMS:  12345678
ArcticWind  -> Ice Wind
Fire Bomb   -> Red Fang
IceShard    -> BlueFang
Lit-Fang    -> GoldFang
Air Slash   -> DuskFang
MagicDart   -> ManaDart
M.Cannon    -> ManaShot
Bloodfeast  -> Redfeast
VoidStone   -> VoidRock
Globe 199   -> Globe199

SUPPPORT ITEMS:12345678
Light Veil  -> LightVeil
EthrMantle  -> Star Veil
Elf Cloak   -> ElfCloak
Lnr.Mirror  -> Mirror // "Lunarian Mirror" IN DIALOGUE



